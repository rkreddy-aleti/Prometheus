# install node exporter with init.d service

# Steps
1. Run `install-node-exporter.sh'
     This will create the directory structure, download the software and run the service as init.directory
