#!/bin/sh
 
/opt/node-exporter/node_exporter --no-collector.diskstats